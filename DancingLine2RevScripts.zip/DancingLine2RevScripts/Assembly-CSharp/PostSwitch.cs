﻿//ByShiro
//The script maybe not work in some case, if there's bug I'm really don't know how to fix it
//And I don't know if it work on PostProcessingStack then it will be have bug
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering.PostProcessing;

namespace DancingLine2RevScripts{
	public class PostSwitch : MonoBehaviour{
		//Drag the post volume to this var
		public PostProcessVolume Post;
		//If Unity can't find the post then it will be created
		private GameObject Post2;
		//Don't change to any value because when it work the value will be cleared
		private int PostInt;
		//Unfinished
		private bool CanFind;
		
		private void Start() {
			Post = FindObjectOfType<PostProcessVolume>();
			CanFind = true;
			if (!CanFind)
			{
				
			}
			
		}

		
		private void Update() {
			PostInt = PlayerPrefs.GetInt("PostData");
			if (PostInt == 1){
				Post.enabled = false;
			}
			if (PostInt == 2){
				Post.enabled = true;
			}
			if (PostInt != 2 && PostInt !=1) {
				Post.enabled = false;;
			}
		}
	}
}

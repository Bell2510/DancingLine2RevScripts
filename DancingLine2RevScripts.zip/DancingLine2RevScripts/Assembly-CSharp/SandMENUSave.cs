using System;
using UnityEngine;
using UnityEngine.UI;

public class SandMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestSand", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestSand", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

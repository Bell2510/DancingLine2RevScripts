﻿using System;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class Quit : MonoBehaviour
{
	public void Click()
	{
		Application.Quit();
		Debug.Log("Done");
	}
}

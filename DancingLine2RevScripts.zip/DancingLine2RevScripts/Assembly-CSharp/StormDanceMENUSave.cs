using System;
using UnityEngine;
using UnityEngine.UI;

public class StormDanceMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestStormDance", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestStormDance", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

using System;
using UnityEngine;

[Serializable]
public class Teleportation : MonoBehaviour
{
	public Transform destination;
	
	public virtual void OnTriggerEnter(Collider other)
	{
		if (other.tag == "Player")
		{
			other.transform.position = this.destination.position;
		}
	}
}

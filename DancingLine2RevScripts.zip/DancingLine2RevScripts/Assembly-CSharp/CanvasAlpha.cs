﻿using UnityEngine;
using DG.Tweening;

public class CanvasAlpha : MonoBehaviour
{
    public CanvasGroup FirstCanvas, SecondCanvas;
	public float Speed = 0.3f;

    public void ToFirst()
    {
        FirstCanvas.gameObject.SetActive(true);
        DOTween.To(() => FirstCanvas.alpha, x => FirstCanvas.alpha = x, 1, Speed);
        DOTween.To(() => SecondCanvas.alpha, x => SecondCanvas.alpha = x, 0, Speed);
        Invoke("SecondFalse", Speed);
    }

    void SecondFalse()
    {
        SecondCanvas.gameObject.SetActive(false);
    }

    public void ToSecond()
    {
        SecondCanvas.gameObject.SetActive(true);
        DOTween.To(() => SecondCanvas.alpha, x => SecondCanvas.alpha = x, 1, Speed);
        DOTween.To(() => FirstCanvas.alpha, x => FirstCanvas.alpha = x, 0, Speed);
        Invoke("FirstFalse", Speed);
    }

    void FirstFalse()
    {
        FirstCanvas.gameObject.SetActive(false);
    }
 }
﻿using UnityEngine.UI;
using UnityEngine;
using System;
using DG.Tweening;

namespace DancingLine2RevScripts
{
    public class Settings : MonoBehaviour
	{
		public Image SettingsImage;
		public GameObject SettingsObject;
		public Vector2 PosSettings;
		public Vector2 PosSettingsOri;
		public CanvasGroup SettingsPannel;
		public KeyCode FastKeyDoer;
		public Ease SettingsEaseMove;
		
		private void Start()
		{
			SettingsPannel.gameObject.SetActive(false);
			SettingsPannel.alpha = 0f;
			SettingsPannel.gameObject.SetActive(false);
		}
		
		private void Update()
		{
			SettingsImage.gameObject.transform.Rotate(transform.rotation.x, transform.rotation.y, Time.deltaTime * 40f);
			if (Input.GetKeyDown(FastKeyDoer))
			{
				Clicked();
			}
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				Exited();
			}
		}
		
		public void Clicked()
		{
			SettingsPannel.gameObject.SetActive(true);
			SettingsPannel.DOFade(1f, 1f).SetEase(SettingsEaseMove);
			SettingsObject.gameObject.GetComponent<RectTransform>().DOAnchorPos(PosSettings, 1f).SetEase(SettingsEaseMove);
			SettingsObject.GetComponent<Button>().enabled = false;
		}
		
		public void Exited()
		{
			Invoke("InvokeThePannel", 0.3f);
			SettingsPannel.DOFade(0f, 1f).SetEase(SettingsEaseMove);
			SettingsObject.gameObject.GetComponent<RectTransform>().DOAnchorPos(PosSettingsOri, 1f).SetEase(SettingsEaseMove);
			SettingsObject.GetComponent<Button>().enabled = true;
		}
		
		public void InvokeThePannel()
		{
			SettingsPannel.gameObject.SetActive(false);
		}
	}
}

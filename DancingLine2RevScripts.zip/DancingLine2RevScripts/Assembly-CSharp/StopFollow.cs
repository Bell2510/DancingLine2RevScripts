﻿using System;
using UnityEngine;

public class StopFollow : MonoBehaviour
{
    public CameraController Cam;
	
	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Player")
		{
			Cam.enabled = false;
		}
	}
}

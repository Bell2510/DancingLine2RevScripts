using System;
using UnityEngine;

public class PhysicsImpactTrigger : Trigger
{
	public Vector3 force;
	
	private void OnTriggerEnter()
	{
		Rigidbody component = base.GetComponent<Rigidbody>();
		component.AddForce(this.force, ForceMode.Impulse);
	}
}

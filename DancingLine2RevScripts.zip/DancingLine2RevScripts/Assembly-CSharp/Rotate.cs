using System;
using UnityEngine;

public class Rotate : MonoBehaviour
{
	public GameObject Actor;
	public float Rotate1;
	
	private void Update()
	{
		if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
		{
			if (this.Rotate1 == 1f)
			{
				this.Actor.transform.eulerAngles = new Vector3(0f, 0f, 0f);
				this.Rotate1 = 0f;
			}
			else
			{
				this.Actor.transform.eulerAngles = new Vector3(0f, -90f, 0f);
				this.Rotate1 = 1f;
			}
		}
	}
}

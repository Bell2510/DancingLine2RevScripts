using System;
using System.Collections;
using UnityEngine;

public class Trigger : MonoBehaviour
{
	public float delay;
	public bool isOnce;
	public int groupId = -1;
	public ITrigger iTrigger;
	
	protected Trigger()
	{
	}
	
	public void Dispose()
	{
		UnityEngine.Object.Destroy(this);
	}
	
	
	public void OnTriggerEnd()
	{
		if (this.isOnce)
		{
			this.Dispose();
		}
	}
	
	public void OnTriggerStart()
	{
		if (this.delay == 0f)
		{
			this.iTrigger.OnTrigger();
			this.OnTriggerEnd();
		}
		else
		{
			base.StartCoroutine(this.DelayedTriggerStart());
		}
	}
	
	private IEnumerator DelayedTriggerStart()
	{
		yield return new WaitForSeconds(this.delay);
		this.iTrigger.OnTrigger();
		this.OnTriggerEnd();
		yield break;
	}

	public virtual void Start()
	{
		if (this.groupId != -1)
		{
			TriggerManager.AddObjectToGroup(this.groupId, this);
		}
	}
	
	public virtual void Update()
	{
	}
}

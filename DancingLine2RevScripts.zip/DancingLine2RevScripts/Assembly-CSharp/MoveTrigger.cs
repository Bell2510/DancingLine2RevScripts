using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveTrigger : Trigger
{
	private List<GameObject> stickObjects;
	public bool moveOnce;
	public bool continuous;
	public Vector3 vector = default(Vector3);
	private Vector3 realVector = default(Vector3);
	public float loopDelay;
	public float duration;
	private float timer;
	private bool working;
	private Vector3 startPosition;
	
	public Vector3 GetActualVector()
	{
		return this.vector * (Time.deltaTime / this.duration);
	}

	public override void Start()
	{
		base.Start();
		this.startPosition = base.transform.position;
		this.realVector = base.transform.TransformDirection(this.vector);
		this.stickObjects = new List<GameObject>();
	}

	private void OnTriggerEnter()
	{
		Debug.Log("ON TRIGGER");
		if (this.duration > 0f)
		{
			if (this.loopDelay == 0f)
			{
				if (!this.working)
				{
					this.timer = 0f;
					this.working = true;
				}
			}
			else
			{
				base.StartCoroutine(this.DoLoopDelay());
			}
		}
		else
		{
			base.transform.Translate(this.vector);
		}
	}

	private IEnumerator DoLoopDelay()
	{
		yield return new WaitForSeconds(this.loopDelay);
		this.timer = 0f;
		this.working = true;
		yield break;
	}

	public override void Update()
	{
		base.Update();
		float deltaTime = Time.deltaTime;
		if (this.working)
		{
			this.timer += deltaTime;
			if (!this.continuous && this.timer >= this.duration)
			{
				this.stickObjects.Clear();
				base.transform.position = this.startPosition + this.realVector;
				this.startPosition = base.transform.position;
				this.working = false;
				if (this.moveOnce)
				{
					base.Dispose();
				}
			}
			else
			{
				base.transform.Translate(this.vector * (deltaTime / this.duration));
				this.MoveStickObjects();
			}
		}
	}

	private void MoveStickObjects()
	{
		float deltaTime = Time.deltaTime;
		foreach (GameObject gameObject in this.stickObjects)
		{
			gameObject.transform.Translate(this.vector * (deltaTime / this.duration));
		}
	}

	private void OnCollisionEnter(Collision collision)
	{
		Debug.Log("부딪혔다!!!!!" + collision.collider);
		Collider collider = collision.collider;
		this.stickObjects.Add(collider.gameObject);
	}

	private void OnCollisionExit(Collision collision)
	{
		Collider collider = collision.collider;
		this.stickObjects.Remove(collider.gameObject);
	}
}

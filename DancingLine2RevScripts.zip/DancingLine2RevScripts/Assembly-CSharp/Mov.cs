using System;
using System.Collections;
using UnityEngine;

public class Mov : MonoBehaviour
{
	public float moveSpeed = 0.08f;
	public int XDirection = 1;
	public int ZDirection = 1;
	public Vector3 dirX;
	public Vector3 dirZ;
	public bool DefaultX;
	public bool camFollow = true;
	private Vector3 camOffset;
	public int camDistance = 16;
	private int cubeCount;
	public int cubeMax = 500;
	public bool Moving;
	public bool Control;
	public bool Trail;
	public bool Die;
	public bool Shatter = true;
	public int MaxDeathShatter = 4;
	private Rigidbody rigidb;
	private ParticleSystem pSystem;
	private GameObject[] cubeTrails;
	[HideInInspector]
	public Vector3 moveTransform;
	[HideInInspector]
	public Vector3 trailDelta;
	[HideInInspector]
	public Vector3 movementDelta;
	
	public static IEnumerator FadeOut(AudioSource audioSource, float FadeTime)
	{
		float startVolume = audioSource.volume;
		while (audioSource.volume > 0f)
		{
			audioSource.volume -= startVolume * Time.deltaTime / FadeTime;
			yield return null;
		}
		audioSource.Stop();
		audioSource.volume = startVolume;
		yield break;
	}

	protected void Start()
	{
		this.camOffset = base.transform.position - Camera.main.transform.position;
		base.GetComponent<Renderer>().sharedMaterial = new Material(base.GetComponent<Renderer>().sharedMaterial);
		this.dirX = ((this.XDirection != 1) ? Vector3.left : Vector3.right);
		this.dirZ = ((this.ZDirection != 1) ? Vector3.back : Vector3.forward);
		this.moveTransform = ((!this.DefaultX) ? this.dirZ : this.dirX);
		this.rigidb = base.GetComponent<Rigidbody>();
		this.pSystem = base.GetComponent<ParticleSystem>();
	}

	private void Update()
	{
		if (this.camFollow)
		{
			Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, base.transform.position, 0.05f) - this.camOffset / (float)this.camDistance;
		}
		if (!this.Die)
		{
			if (!this.Moving)
			{
				if (Input.GetButtonDown("Turn"))
				{
					this.Moving = true;
					this.Control = true;
					this.Trail = true;
					this.cubeCount++;
					this.CreateTrailObject(base.transform.position);
				}
			}
			else
			{
				if (this.Control && Input.GetButtonDown("Turn") && this.Trail)
				{
					this.cubeCount++;
					this.CreateTrailObject(base.transform.position);
					this.moveTransform = ((!(this.moveTransform == this.dirX)) ? this.dirX : this.dirZ);
				}
				this.movementDelta = this.moveTransform * Time.deltaTime * 60f;
				base.transform.Translate(this.movementDelta * this.moveSpeed);
				if (this.Trail)
				{
					try
					{
						GameObject[] array = GameObject.FindGameObjectsWithTag("PlayerTrail");
						if (array.Length > 0)
						{
							GameObject gameObject = array[array.Length - 1];
							this.trailDelta = this.moveTransform * this.moveSpeed * Time.deltaTime * 60f;
							gameObject.transform.localScale += this.trailDelta;
							gameObject.transform.position -= this.trailDelta / 2f;
							GameObject obj = array[0];
							if (array.Length > this.cubeMax)
							{
								UnityEngine.Object.Destroy(obj);
							}
						}
					}
					catch (UnityException)
					{
						MonoBehaviour.print("No PlayerTrails found?");
					}
				}
			}
		}
		else
		{
			this.Moving = false;
			this.Control = false;
			this.Trail = false;
			this.rigidb.useGravity = false;
			this.rigidb.isKinematic = true;
			UnityEngine.Object.Destroy(base.GetComponent<BoxCollider>());
			if (this.Shatter)
			{
				for (int i = 0; i < this.MaxDeathShatter; i++)
				{
					GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
					gameObject2.layer = 8;
					float num = UnityEngine.Random.Range(-10f, 10f);
					float num2 = UnityEngine.Random.Range(-10f, 10f);
					float num3 = UnityEngine.Random.Range(-10f, 10f);
					Quaternion localRotation = Quaternion.Euler(30f + num, 3f + num2, 30f + num3);
					gameObject2.transform.position = base.transform.position;
					gameObject2.transform.localRotation = localRotation;
					gameObject2.transform.localScale = base.transform.localScale;
					gameObject2.GetComponent<Renderer>().material = base.GetComponent<Renderer>().material;
					Rigidbody rigidbody = gameObject2.AddComponent<Rigidbody>();
					rigidbody.useGravity = true;
					rigidbody.isKinematic = false;
					rigidbody.angularDrag = 0.7f;
					rigidbody.drag = 0.2f;
					rigidbody.mass = 0.2f;
				}
				this.Shatter = false;
				AudioSource component = Camera.main.GetComponent<AudioSource>();
				base.StartCoroutine(Mov.FadeOut(component, 6f));
				AudioSource component2 = base.GetComponent<AudioSource>();
				component2.mute = false;
				component2.Play();
			}
		}
	}

	public void CreateTrailObject(Vector3 pos)
	{
		GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
		gameObject.transform.position = pos;
		gameObject.transform.localScale = base.transform.localScale;
		gameObject.GetComponent<Renderer>().material = base.GetComponent<Renderer>().material;
		gameObject.tag = "PlayerTrail";
		UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
	}
}

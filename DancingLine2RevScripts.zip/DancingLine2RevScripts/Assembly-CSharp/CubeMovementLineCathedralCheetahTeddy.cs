using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class CubeMovementLineCathedralCheetahTeddy : MonoBehaviour
{
	public GameObject Actor;
	public Button ButtonToStartGame;
	public float speed = 1f;
	private Vector3 pos;
	public Material mat;
	private int loopCount = 1;
	public bool onGround = true;
	public float distFromGround = 0.6f;
	public bool isAlive = true;
	private bool MatChange;
	private bool MatChange2;
	public Material MatToChange;
	public Material MatToChange2;
	private Renderer _renderer;
	public UIFader Result;
	public UIFader Result2;
	public int CurrentPercentage;
	public Text percentage;
	public Text percentage2;
	public AudioClip MusicClip;
	public AudioSource MusicSource;
	public Animator anim;
	public Animation Doer;
	public int CrownCollected;
	public GameObject UI;
	public GameObject UIComplete;
	public GameObject collection;
	public bool Started;
	public bool OneTime;
	public GameObject UIStart;
	public int approxSecondsToFade = 4;
	public Animator ArmL;
	public Animator ArmR;
	public Animator LegL;
	public Animator LegR;
	[HideInInspector] public Animator[] PlayerAnim;
	[HideInInspector] public Animation[] PlayerAnimation;
	
	private void Start()
	{
		this.Doer.enabled = false;
		PlayerAnim = FindObjectsOfType<Animator>();
		PlayerAnimation = FindObjectsOfType<Animation>();
		Button component = this.ButtonToStartGame.GetComponent<Button>();
		this._renderer = this.Actor.GetComponent<MeshRenderer>();
		this.SetPercentageText();
		this.MusicSource.clip = this.MusicClip;
		this.CrownCollected = 0;
		component.onClick.AddListener(new UnityAction(this.TaskOnClick));
		this.Started = false;
		this.OneTime = false;
		this.anim.enabled = false;
		this.ArmL.enabled = false;
		this.ArmR.enabled = false;
		this.LegL.enabled = false;
		this.LegR.enabled = false;
		this.MusicSource.Stop();
	}

	private void TaskOnClick()
	{
		if (!this.OneTime)
		{
			this.Started = true;
			this.MusicSource.Play();
			this.OneTime = true;
			this.UIStart.gameObject.SetActive(false);
			this.ArmL.enabled = true;
			this.ArmR.enabled = true;
			this.LegL.enabled = true;
			this.LegR.enabled = true;
		}
	}

	private void Update()
	{
		if (this.Started)
		{
			this.anim.enabled = true;
			this.Doer.enabled = true;
			this.collection = GameObject.FindGameObjectWithTag("cubes");
			this.SetPercentageText();
			if (this.MatChange2)
			{
				this._renderer.material.Lerp(this.mat, this.MatToChange2, 0.01f);
				this.mat = this._renderer.material;
				this.MatChange = false;
			}
			if (this.MatChange)
			{
				this._renderer.material.Lerp(this.mat, this.MatToChange, 0.01f);
				this.mat = this._renderer.material;
			}
			if (this.isAlive)
			{
				this.onGround = this.isGrounded();
				this.pos = this.Actor.transform.position;
				this.Actor.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
				if (this.onGround && (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space)))
				{
					if (this.loopCount % 2 != 1)
					{
						this.Actor.transform.eulerAngles = new Vector3(0f, 0f, 0f);
						this.loopCount++;
					}
					else
					{
						this.Actor.transform.eulerAngles = new Vector3(0f, 90f, 0f);
						this.loopCount++;
					}
				}
			}
			else
			{
				this.anim.enabled = false;
				this.MusicSource.volume = this.MusicSource.volume - Time.deltaTime / (float)this.approxSecondsToFade;
			}
		}
	}

	public bool isGrounded()
	{
		return Physics.Raycast(this.Actor.transform.position, Vector3.down, this.distFromGround);
	}

	private void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.tag == "obstacle")
		{
			for (int i = 0; i < PlayerAnim.Length; i++)
			{
				PlayerAnim[i].enabled = false;
			}
			for (int i = 0; i < PlayerAnimation.Length; i++)
			{
				PlayerAnimation[i].enabled = false;
			}
			this.isAlive = false;
			this.UI.gameObject.SetActive(true);
			this.Result.FadeIn();
			this.ArmL.enabled = false;
			this.ArmR.enabled = false;
			this.LegL.enabled = false;
			this.LegR.enabled = false;
		}
		if (collision.gameObject.tag == "endobstacle")
		{
			this.isAlive = false;
			this.UIComplete.gameObject.SetActive(true);
			this.Result2.FadeIn();
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "MatChange")
		{
			this.MatChange = true;
		}
		if (other.gameObject.tag == "MatChange2")
		{
			this.MatChange2 = true;
		}
		if (other.gameObject.tag == "Gem")
		{
			other.gameObject.SetActive(false);
		}
		if (other.gameObject.tag == "Crown")
		{
			other.gameObject.SetActive(false);
			this.CrownCollected++;
		}
	}

	private void SetPercentageText()
	{
		if (this.CurrentPercentage < 100 && this.isAlive)
		{
			this.CurrentPercentage = Mathf.RoundToInt(this.MusicSource.time / (this.MusicClip.length - 6f) * 100f);
			this.percentage.text = this.CurrentPercentage.ToString() + "%";
			this.percentage2.text = this.CurrentPercentage.ToString();
		}
	}
}

using System;
using System.Collections;
using UnityEngine;

public class RotateTrigger : Trigger
{
	public Vector3 rotation = default(Vector3);
	private Vector3 startAngle;
	public float duration;
	public bool continuous;
	public bool rotateOnce;
	public bool preStart;
	public float loopDelay;
	private bool waiting;
	private float timer;
	private bool working;
	
	public override void Start()
	{
		base.Start();
		this.startAngle = base.transform.eulerAngles;
		if (this.preStart)
		{
			this.working = true;
		}
	}

	public override void Update()
	{
		base.Update();
		if (this.duration <= 0f)
		{
			return;
		}
		float deltaTime = Time.deltaTime;
		if (this.working)
		{
			this.timer += deltaTime;
			float d = deltaTime / this.duration;
			base.transform.Rotate(this.rotation * d);
			if (!this.continuous && this.timer > this.duration)
			{
				this.StartLoopDelay();
				base.transform.rotation = Quaternion.Euler(this.startAngle + this.rotation);
				Debug.Log(base.transform.rotation);
				this.working = false;
				if (this.rotateOnce)
				{
					base.Dispose();
				}
			}
		}
	}

	private void StartLoopDelay()
	{
		if (this.loopDelay > 0f)
		{
			base.StartCoroutine(this.DoLoopDelay());
		}
	}

	private IEnumerator DoLoopDelay()
	{
		this.waiting = true;
		yield return new WaitForSeconds(this.loopDelay);
		this.waiting = false;
		yield break;
	}

	private void OnTriggerEnter()
	{
		if (this.duration > 0f && !this.working && !this.waiting)
		{
			this.timer = 0f;
			this.working = true;
		}
		else if (this.duration == 0f)
		{
			base.transform.Rotate(this.rotation);
		}
	}
}

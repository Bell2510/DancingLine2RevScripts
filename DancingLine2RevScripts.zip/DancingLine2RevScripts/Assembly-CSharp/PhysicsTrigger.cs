using System;
using UnityEngine;

public class PhysicsTrigger : Trigger
{
	public float destroyY = -30f;
	public float mass = 1f;
	public bool randomImpact;
	public bool isImpactOnce = true;
	private bool impact;
	public Vector3 impactForce = default(Vector3);
	
	public override void Start()
	{
		base.Start();
	}

	public override void Update()
	{
		base.Update();
		if (base.transform.position.y < this.destroyY)
		{
			UnityEngine.Object.Destroy(base.gameObject);
		}
	}

	private void OnTriggerEnter()
	{
		Rigidbody rigidbody;
		if (base.GetComponent<Rigidbody>() == null)
		{
			rigidbody = base.gameObject.AddComponent<Rigidbody>();
			rigidbody.mass = this.mass;
		}
		else
		{
			rigidbody = base.gameObject.GetComponent<Rigidbody>();
		}
		Vector3 force = this.impactForce;
		if (this.randomImpact)
		{
			force.x *= UnityEngine.Random.Range(-1f, 1f);
			force.y *= UnityEngine.Random.Range(-1f, 1f);
			force.z *= UnityEngine.Random.Range(-1f, 1f);
		}
		if (!this.isImpactOnce)
		{
			rigidbody.AddForce(force, ForceMode.Impulse);
		}
		else if (!this.impact)
		{
			rigidbody.AddForce(force, ForceMode.Impulse);
			this.impact = true;
		}
	}
}

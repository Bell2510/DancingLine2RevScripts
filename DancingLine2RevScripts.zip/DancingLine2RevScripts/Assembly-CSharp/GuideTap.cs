﻿using System;
using UnityEngine;

namespace DancingLine2RevScripts
{
	public class GuideTap : MonoBehaviour
	{
		public GameObject EffectTapers;
		private bool Done = false;
		
		void Update()
		{
			GetComponent<BoxCollider>().size = new Vector3(1.3f, 1.3f, 1.5f);
		}
		
		void OnTriggerStay(Collider other)
		{
			if (other.gameObject.tag == "Player")
			{
				if (!Done)
				{
					if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
                    {
                        Instantiate(EffectTapers, transform.position, transform.rotation);
                        Destroy(gameObject);
                    }
				}
			}
		}
	}
}
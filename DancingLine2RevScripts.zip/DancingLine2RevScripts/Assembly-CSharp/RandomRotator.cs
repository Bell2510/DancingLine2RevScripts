using System;
using UnityEngine;

public class RandomRotator : MonoBehaviour
{
	[SerializeField]
	private float tumble;
	
	private void Start()
	{
		base.GetComponent<Rigidbody>().angularVelocity = UnityEngine.Random.insideUnitSphere * this.tumble;
	}
}

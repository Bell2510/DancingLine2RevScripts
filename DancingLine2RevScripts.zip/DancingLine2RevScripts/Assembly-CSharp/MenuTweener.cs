﻿using System;
using UnityEngine.UI;
using UnityEngine;
using DG.Tweening;

namespace DancingLine2RevScripts
{
    public class MenuTweener : MonoBehaviour
	{
		public GameObject LevelHolder;
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
using DancingLine2RevScripts;

public class Crown : MonoBehaviour
{
    public CrownTrigger Target;
	
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Player")
		{
			Target.Trigger();
		}
	}

}

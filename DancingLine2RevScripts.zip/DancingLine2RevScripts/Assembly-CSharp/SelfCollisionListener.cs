using System;
using UnityEngine;

public class SelfCollisionListener : MonoBehaviour
{
	private void OnTriggerEnter(Collider collider)
	{
		if (collider.CompareTag("Player"))
		{
			this.CallTriggers();
		}
	}

	private void OnCollisionEnter(Collision collision)
	{
		Collider collider = collision.collider;
		if (collider.CompareTag("Player"))
		{
			this.CallTriggers();
		}
	}

	private void CallTriggers()
	{
		TriggerManager.Call(base.gameObject);
	}
}

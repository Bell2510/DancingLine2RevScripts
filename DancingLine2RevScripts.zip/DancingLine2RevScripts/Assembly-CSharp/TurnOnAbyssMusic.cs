using System;
using UnityEngine;

public class TurnOnAbyssMusic : MonoBehaviour
{
	public GameObject Music;
	public GameObject Rotator;
	
	private void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")
		{
			this.Music.gameObject.SetActive(true);
			this.Rotator.gameObject.SetActive(true);
			GameObject[] array = GameObject.FindGameObjectsWithTag("Cube1");
			foreach (GameObject obj in array)
			{
				UnityEngine.Object.Destroy(obj);
			}
		}
	}
}

using System;
using UnityEngine;
using UnityEngine.UI;

public class GameMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestGame", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestGame", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

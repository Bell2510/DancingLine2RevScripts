﻿using System;
using UnityEngine.UI;
using UnityEngine;
using System.Collections;
using DG.Tweening;

namespace DancingLine2RevScripts
{
    public class InfosLevel : MonoBehaviour
	{
		[HideInInspector] public AudioSource MusicObject;
		public GameObject NextLevel;
		public GameObject LastLevel;
		public Text LevelText, DiamondText, PercentText, LevelCount;
		public string LevelName;
		public string LevelCountString;
		public AudioClip LevelSound;
		public AudioSource LevelSource;
		public AudioSource NextLevelSource;
		public AudioSource LastLevelSource;
		public Image DiamondIcon, LevelBG;
		public Sprite LevelImage, LevelValue;
		public Color LevelTheme = new Color(1f, 1f, 1f, 1f);
		
		void Start()
		{
			this.LevelCount.color = this.LevelTheme;
			this.PercentText.color = this.LevelTheme;
			this.LevelCount.color = this.LevelTheme;
			this.LevelText.color = this.LevelTheme;
			this.DiamondText.color = this.LevelTheme;
			this.DiamondIcon.sprite = this.LevelValue;
			this.LevelText.text = this.LevelName;
			this.LevelCount.text = this.LevelCountString;
			this.LevelBG.sprite = this.LevelImage;
			this.NextLevel.gameObject.GetComponent<CanvasGroup>().alpha = 0f;
			this.LastLevel.gameObject.GetComponent<CanvasGroup>().alpha = 0f;
			this.LevelSource.clip = this.LevelSound;
		}
		
		void ThisFalse()
		{
			this.gameObject.SetActive(false);
			this.LevelSource.DOFade(0f, 0.1f);
			Invoke("SoundFalse", 0.1f);
		}
		
		void SoundFalse()
		{
			this.LevelSource.gameObject.SetActive(false);
		}
		
		public void NextClicked()
		{
			GetComponent<CanvasGroup>().DOFade(0f, 0.5f);
			Invoke("ThisFalse", 0.6f);
			NextLevel.gameObject.SetActive(true);
			this.NextLevelSource.gameObject.SetActive(true);
			NextLevel.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			NextLevelSource.DOFade(1f, 1f);
			
		}
		
		public void LeftClicked()
		{
			GetComponent<CanvasGroup>().DOFade(0f, 0.5f);
			Invoke("ThisFalse", 0.6f);
			LastLevel.gameObject.SetActive(true);
			this.LastLevelSource.gameObject.SetActive(true);
			LastLevel.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			LastLevelSource.DOFade(1f, 1f);
		}
		
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.LeftArrow))
			{
				StartCoroutine(FastKeyLeft());
			}
			if (Input.GetKeyDown(KeyCode.RightArrow))
			{
				StartCoroutine(FastKeyRight());
			}
		}
		
		private IEnumerator FastKeyLeft()
		{
			yield return new WaitForSeconds(0.2f);
			LeftClicked();
		}
		
		private IEnumerator FastKeyRight()
		{
			yield return new WaitForSeconds(0.2f);
			NextClicked();
		}
	}
}

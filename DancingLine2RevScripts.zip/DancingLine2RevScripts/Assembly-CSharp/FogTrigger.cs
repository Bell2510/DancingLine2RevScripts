using System;
using UnityEngine;

public class FogTrigger : MonoBehaviour
{
	public float min;
	public float max;
	public float t;
	
	private void Start()
	{
		RenderSettings.fogDensity = 0f;
	}
	
	private void OnTriggerEnter(Collider collider)
	{
		if (collider.gameObject.tag == "Player")
		{
			RenderSettings.fogDensity = Mathf.Lerp(this.min, this.max, this.t);
		}
	}
}

using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using System.Collections;
using DG.Tweening;

public class CubeMovementLineCathedral : MonoBehaviour
{
	[Header("Objects")]
	public GameObject Actor;
	public GameObject DieSound;
	public GameObject DieEffect;
	public GameObject LandEffect;
	public Button ButtonToStartGame;
	public Color PlayerColor;
	public Color GemColor;
	public float speed = 1f;
	public float distFromGround = 0.6f;
	private Vector3 pos;
	public Material mat;
	public bool onGround = true;
	public bool isAlive = true;
	private bool MatChange;
	private bool MatChange2;
	public bool Started;
	public bool OneTime;
	public bool CanDie = true;
	
	[Header("Edit")]
	public Material MatToChange;
	public Material MatToChange2;
	private Renderer _renderer;
	public UIFader Result;
	public UIFader Result2;
	public int CurrentPercentage;
	public int approxSecondsToFade = 4;
	public int CrownCollected;
	private int loopCount = 1;
	public Text percentage;
	public Text percentage2;
	public AudioClip MusicClip;
	public AudioSource MusicSource;
	public Animator anim;
	public Animation Doer;
	public GameObject UI;
	public GameObject UIComplete;
	public GameObject collection;
	public GameObject UIStart;
	public Material ThemeMaterial;
	[HideInInspector] public Animator[] PlayerAnim;
	[HideInInspector] public Animation[] PlayerAnimation;
	[HideInInspector] public GameObject[] Obstacle;
	
	
	private void Start()
	{
		CanDie = true;
		//OnlyForNightCold
		Obstacle =  GameObject.FindGameObjectsWithTag("obstacle");
		for (int a = 0; a < Obstacle.Length; a++)
		{
			if (CanDie == false)
			{
				Obstacle[a].gameObject.SetActive(CanDie);
			}
		}
		ThemeMaterial.color = PlayerColor;
		PlayerAnim = FindObjectsOfType<Animator>();
		PlayerAnimation = FindObjectsOfType<Animation>();
		Button component = this.ButtonToStartGame.GetComponent<Button>();
		this._renderer = this.Actor.GetComponent<MeshRenderer>();
		this.SetPercentageText();
		this.MusicSource.clip = this.MusicClip;
		this.CrownCollected = 0;
		component.onClick.AddListener(new UnityAction(this.TaskOnClick));
		this.Started = false;
		this.OneTime = false;
		this.anim.enabled = false;
		this.MusicSource.Stop();
	}

	private void TaskOnClick()
	{
		if (!this.OneTime)
		{
			this.Started = true;
			this.MusicSource.Play();
			this.OneTime = true;
			this.UIStart.gameObject.SetActive(false);
		}
	}

	private void Update()
	{
		if (this.Started)
		{
			this.anim.enabled = true;
			this.collection = GameObject.FindGameObjectWithTag("cubes");
			this.SetPercentageText();
			if (this.MatChange2)
			{
				this._renderer.material.Lerp(this.mat, this.MatToChange2, 0.01f);
				this.mat = this._renderer.material;
				this.MatChange = false;
			}
			if (this.MatChange)
			{
				this._renderer.material.Lerp(this.mat, this.MatToChange, 0.01f);
				this.mat = this._renderer.material;
			}
			if (this.isAlive)
			{
				this.onGround = this.isGrounded();
				this.pos = this.Actor.transform.position;
				this.Actor.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
				if (this.onGround)
				{
					GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
					gameObject.transform.position = this.pos;
					gameObject.GetComponent<MeshRenderer>().material = this.mat;
					gameObject.GetComponent<BoxCollider>().isTrigger = true;
					gameObject.tag = "cubes";
					if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
					{
						if (this.loopCount % 2 != 1)
						{
							this.Actor.transform.eulerAngles = new Vector3(0f, 0f, 0f);
							this.loopCount++;
						}
						else
						{
							this.Actor.transform.eulerAngles = new Vector3(0f, 90f, 0f);
							this.loopCount++;
						}
					}
				}
			}
			else
			{
				this.anim.enabled = false;
				this.MusicSource.volume = this.MusicSource.volume - Time.deltaTime / (float)this.approxSecondsToFade;
			}
		}
	}

	public bool isGrounded()
	{
		return Physics.Raycast(Actor.transform.position, Vector3.down, distFromGround);
	}

	private void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.tag == "obstacle")
		{
			for (int i = 0; i < PlayerAnim.Length; i++)
			{
				PlayerAnim[i].enabled = false;
			}
			for (int i = 0; i < PlayerAnimation.Length; i++)
			{
				PlayerAnimation[i].enabled = false;
			}
			this.isAlive = false;
			Instantiate(DieEffect, transform.position, transform.rotation);
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject.transform.position = this.pos;
			gameObject2.transform.position = this.pos;
			gameObject3.transform.position = this.pos;
			gameObject.AddComponent<Rigidbody>().velocity = UnityEngine.Random.onUnitSphere * 5f;
			gameObject2.AddComponent<Rigidbody>().velocity = UnityEngine.Random.onUnitSphere * 5f;
			gameObject3.AddComponent<Rigidbody>().velocity = UnityEngine.Random.onUnitSphere * 5f;
			gameObject.GetComponent<MeshRenderer>().material = this.mat;
			gameObject2.GetComponent<MeshRenderer>().material = this.mat;
			gameObject3.GetComponent<MeshRenderer>().material = this.mat;
			this.UI.gameObject.SetActive(true);
			this.Result.FadeIn();
			gameObject.tag = "cubes";
			gameObject2.tag = "cubes";
			gameObject3.tag = "cubes";
		}
		if (collision.gameObject.tag == "endobstacle")
		{
			this.isAlive = false;
			this.UIComplete.gameObject.SetActive(true);
			this.Result2.FadeIn();
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "MatChange")
		{
			this.MatChange = true;
		}
		if (other.gameObject.tag == "MatChange2")
		{
			this.MatChange2 = true;
		}
		if (other.gameObject.tag == "Gem")
		{
			other.gameObject.SetActive(false);
		}
		if (other.gameObject.tag == "Crown")
		{
			other.gameObject.SetActive(false);
			this.CrownCollected += 1 ;
		}
	}

	private void SetPercentageText()
	{
		if (this.CurrentPercentage < 100 && this.isAlive)
		{
			this.CurrentPercentage = Mathf.RoundToInt(this.MusicSource.time / (this.MusicClip.length - 6f) * 100f);
			this.percentage.text = this.CurrentPercentage.ToString() + "%";
			this.percentage2.text = this.CurrentPercentage.ToString();
		}
	}
}

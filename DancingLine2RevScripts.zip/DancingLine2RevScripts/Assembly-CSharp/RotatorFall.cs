using System;
using UnityEngine;

public class RotatorFall : MonoBehaviour
{
	public GameObject Object;
	
	private void OnTriggerEnter(Collider other)
	{
		if (other.tag == "Path")
		{
			this.Object.SetActive(true);
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (other.tag == "Path")
		{
			this.Object.SetActive(false);
		}
	}
}

﻿using UnityEngine.UI;
using UnityEngine;
using System;
using DG.Tweening;
//DancingLine2 only have 3 skin, it's Normal, Heaphone, Teddy

namespace DancingLine2RevScripts
{
    public class SkinManager : MonoBehaviour
	{
		[Header("Theme Color")]
		public Color ColorSkin1 = new Color(1f, 1f, 1f, 1f);
		public Color ColorSkin2 = new Color(1f, 1f, 1f, 1f);
		public Color ColorSkin3 = new Color(1f, 1f, 1f, 1f);
		
		[Header("Image Object")]
		public Image Image1;
		public Image Image2;
		public Image Image3;
		
		[Header("Sprite")]
		public Sprite ImageSkin1;
		public Sprite ImageSkin2;
		public Sprite ImageSkin3;
		
		[Header("Object")]
		public GameObject Skin1;
		public GameObject Skin2;
		public GameObject Skin3;
		
		[Header("Button")]
		public Button Skin1B;
		public Button Skin2B;
		public Button Skin3B;
		
		[Header("Animator1")]
		public Vector2 Pos1;
		public Ease Ease1;
		public float TimeFade1;
		
		[Header("Animator2")]
		public Vector2 Pos2;
		public Ease Ease2;
		public float TimeFade2;
		
		[Header("Animator3")]
		public Vector2 Pos3;
		public Ease Ease3;
		public float TimeFade3;
		
		private int SkinID;
		
		void Start()
		{
			Image1.sprite = ImageSkin1;
			Image2.sprite = ImageSkin2;
			Image3.sprite = ImageSkin3;
			Image1.color = ColorSkin1;
			Image2.color = ColorSkin2;
			Image3.color = ColorSkin3;
			Skin1B.gameObject.SetActive(true);
			Skin2B.gameObject.SetActive(true); 
			Skin3B.gameObject.SetActive(true);
			
		}
		
		public void SetIntNumber(int IntValue)
		{
			PlayerPrefs.SetInt("SkinID", IntValue);
		}
		
		public void ClickSkin1()
		{
			    Skin1.SetActive(true);
			    Skin2.SetActive(false);
			    Skin3.SetActive(false);
				Skin1B.gameObject.GetComponent<CanvasGroup>().DOFade(0.5f, 0.5f);
			    Skin2B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Skin3B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Debug.Log("Skin1 activated");
		}
		
		public void ClickSkin2()
		{
			    Skin1.SetActive(false);
			    Skin2.SetActive(true);
			    Skin3.SetActive(false);
				Skin1B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Skin2B.gameObject.GetComponent<CanvasGroup>().DOFade(0.5f, 0.5f);
			    Skin3B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Debug.Log("Skin2 activated");
		}
		
		public void ClickSkin3()
		{
			    Skin1.SetActive(false);
			    Skin2.SetActive(false);
			    Skin3.SetActive(true);
				Skin1B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Skin2B.gameObject.GetComponent<CanvasGroup>().DOFade(1f, 0.5f);
			    Skin3B.gameObject.GetComponent<CanvasGroup>().DOFade(0.5f, 0.5f);
			    Debug.Log("??? activated");
		}
		
		
		public void OnStartPlay()
		{
			GetComponent<CanvasGroup>().DOFade(0f, 1.5f);
			Skin1B.gameObject.GetComponent<RectTransform>().DOAnchorPos(Pos1, TimeFade1).SetEase(Ease1);
			Skin2B.gameObject.GetComponent<RectTransform>().DOAnchorPos(Pos2, TimeFade2).SetEase(Ease2);
			Skin3B.gameObject.GetComponent<RectTransform>().DOAnchorPos(Pos3, TimeFade3).SetEase(Ease3);
			Skin1B.gameObject.GetComponent<CanvasGroup>().DOFade(0f, TimeFade1).SetEase(Ease1);
			Skin2B.gameObject.GetComponent<CanvasGroup>().DOFade(0f, TimeFade2).SetEase(Ease2);
			Skin3B.gameObject.GetComponent<CanvasGroup>().DOFade(0f, TimeFade3).SetEase(Ease3);
		}
		
		public void InvokeStartPlay()
		{
			this.gameObject.SetActive(false);
			Skin1B.gameObject.SetActive(false);
			Skin2B.gameObject.SetActive(false);
			Skin3B.gameObject.SetActive(false);
		}
	}
}

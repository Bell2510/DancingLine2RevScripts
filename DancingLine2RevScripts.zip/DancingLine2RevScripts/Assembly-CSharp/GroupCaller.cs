using System;
using System.Collections.Generic;

public class GroupCaller : Trigger
{
	public List<int> groups;
	
	private void OnTriggerEnter()
	{
		this.CallTriggers();
	}

	private void CallTriggers()
	{
		if (this.groups.Count > 0)
		{
			for (int i = 0; i < this.groups.Count; i++)
			{
				TriggerManager.Call(this.groups[i]);
			}
		}
	}
}

using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Credits : MonoBehaviour
{
	private void Start()
	{
		base.StartCoroutine(this.loadSceneAfterDelay(40f));
	}
	
	private IEnumerator loadSceneAfterDelay(float waitbySecs)
	{
		yield return new WaitForSeconds(waitbySecs);
		SceneManager.LoadScene("MainMenu");
		yield break;
	}
}

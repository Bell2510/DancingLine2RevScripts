using System;
using UnityEngine;

public class CubeRemoveAbyssCheetah : MonoBehaviour
{
	private void OnTriggerEnter(Collider col)
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("TerrainObject");
		for (int i = 0; i < array.Length; i++)
		{
			UnityEngine.Object.Destroy(array[i]);
		}
	}
}

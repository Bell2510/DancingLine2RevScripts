﻿using UnityEngine.UI;
using UnityEngine;
using System;

public class TextManager : MonoBehaviour
{
    [Serializable]
	public class TextDoer
	{
		public Text Text;
		public string Content;
	}
	
	public TextDoer[] TextCotroller;
	
	void Awake()
	{
		for (int i = 0; i < TextCotroller.Length; i++)
		{
			TextCotroller[i].Text.text = TextCotroller[i].Content;
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Active : MonoBehaviour
{
    public GameObject Object1;
	public GameObject Object2;
	public GameObject Object3;
	
	public void Object1C()
	{
		Object1.gameObject.SetActive(true);
		Object2.gameObject.SetActive(false);
		Object3.gameObject.SetActive(false);
	}
	
	public void Object2C()
	{
		Object1.gameObject.SetActive(false);
		Object2.gameObject.SetActive(true);
		Object3.gameObject.SetActive(false);
	}
	
	public void Object3C()
	{
		Object1.gameObject.SetActive(false);
		Object2.gameObject.SetActive(false);
		Object3.gameObject.SetActive(true);
	}
}

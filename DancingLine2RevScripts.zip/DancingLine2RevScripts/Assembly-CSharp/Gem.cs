using System;
using UnityEngine;

public class Gem : MonoBehaviour
{
	public Vector3 rotationPerSecond;
	public Color Theme;
	public Material ThemeDiaMat;
	public GameObject EffectOnCollected;
	
	private void Start()
	{
		ThemeDiaMat.color = Theme;
	}

	private void Update()
	{
		base.transform.Rotate(this.rotationPerSecond * Time.deltaTime);
	}

	private void OnTriggerEnter(Collider collider)
	{
		if (collider.CompareTag("Player"))
		{
			UnityEngine.Object.Destroy(base.gameObject);
			Instantiate(EffectOnCollected, transform.position, Quaternion.Euler(-90f, 0f, 0f));
		}
	}
}

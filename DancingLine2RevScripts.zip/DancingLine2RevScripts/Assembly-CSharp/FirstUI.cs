﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System; 
using UnityEngine.UI;
using DG.Tweening;

namespace DancingLine2RevScripts {
    public class FirstUI : MonoBehaviour {
		public CanvasGroup Object;
		public GameObject DontDestroyObject;
		
		void Awake() {
			Object.alpha = 1f;
			Invoke("DoStart", 3f);
			Object.gameObject.SetActive(true);
		}

		public void DoStart() {
			Object.DOFade(0f, 1f);
			Invoke("Done", 1f);
		}
		
		public void Done() {
			Object.gameObject.SetActive(false);
			Debug.Log("Load done!");
			Invoke("DontDestroyTheObject", 0.5f);
		}
		
		public void DontDestroyTheObject() {
			DontDestroyOnLoad(DontDestroyObject);
		}
	}
}

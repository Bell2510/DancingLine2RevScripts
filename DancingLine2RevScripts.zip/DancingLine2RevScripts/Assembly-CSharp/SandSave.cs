using System;
using UnityEngine;
using UnityEngine.UI;

public class SandSave : MonoBehaviour
{
	public Text CurrentScore;
	public Text HighScore;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestSand", 0);
		this.HighScore.text = @int.ToString();
	}

	private void Update()
	{
		int num;
		int.TryParse(this.CurrentScore.text, out num);
		int @int = PlayerPrefs.GetInt("BestSand", 0);
		if (num > @int)
		{
			this.HighScore.text = num.ToString();
			PlayerPrefs.SetInt("BestSand", num);
		}
	}
}

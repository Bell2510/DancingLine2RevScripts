﻿using System;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class ComboActivator : MonoBehaviour
{
	public Activator[] ActivatorObject;
	public Animators[] AnmationObject;
	public ParticlePLayer[] ParticleObject;
	public VideoPlaying[] VideoObject;
	public AudioPlaying[] AudioObject;
	
	[Serializable]
    public class Activator
	{
		public GameObject Object;
		public bool Active;
	}
		
	[Serializable]
    public class Animators
	{
		public Animator Object;
		public bool Play;
	}
		
	[Serializable]
    public class ParticlePLayer
	{
		public GameObject Object;
		public bool Start;
	}
	
	[Serializable]
	public class VideoPlaying
	{
		public UnityEngine.Video.VideoPlayer VideoObject;
		public bool Start;
	}
	
	[Serializable]
	public class AudioPlaying
	{
		public AudioSource Audio;
		public GameObject AudioDoer;
		public bool Start;
	}
		
	void OnTriggerEnter(Collider other) 
	{
		if (other.gameObject.tag == "Player") 
		{
			for (int i = 0; i < ActivatorObject.Length; i++)
			{
				ActivatorObject[i].Object.SetActive(ActivatorObject[i].Active);
			}
				
			for (int h = 0; h < ParticleObject.Length; h++)
			{
				if (ParticleObject[h].Start == true)
				{
					ParticleObject[h].Object.SetActive(true);
				}
				else 
				{
					ParticleObject[h].Object.SetActive(false);
				}
			}
				
			for (int k = 0; k < AnmationObject.Length; k++)
			{
				if (AnmationObject[k].Play == true) 
				{
					AnmationObject[k].Object.enabled = true;
				}
				else 
				{
					AnmationObject[k].Object.enabled = false;
				}
					
			}
				
		}
			
	}

}
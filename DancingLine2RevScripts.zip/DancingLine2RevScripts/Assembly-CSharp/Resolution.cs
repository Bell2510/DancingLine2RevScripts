﻿using System;
using UnityEngine;

public class Resolution : MonoBehaviour
{
	public int width;
	public int height;
	public string fullscreen;
	
	private void Awake()
	{
		PlayerPrefs.SetInt("width", Screen.width);
		PlayerPrefs.SetInt("height", Screen.height);
	}

	public void SetResolution()
	{
		this.fullscreen = PlayerPrefs.GetString("FullScreen");
		if (this.fullscreen == "true")
		{
			Screen.SetResolution(this.width, this.height, true);
		}
		else if (this.fullscreen == "false")
		{
			Screen.SetResolution(this.width, this.height, false);
		}
		PlayerPrefs.SetInt("width", this.width);
		PlayerPrefs.SetInt("height", this.height);
	}

	public void OnOffFullScreen()
	{
		this.width = PlayerPrefs.GetInt("width");
		this.height = PlayerPrefs.GetInt("height");
		if (this.fullscreen == "true")
		{
			Screen.SetResolution(this.width, this.height, true);
		}
		else if (this.fullscreen == "false")
		{
			Screen.SetResolution(this.width, this.height, false);
		}
		PlayerPrefs.SetString("FullScreen", this.fullscreen);
	}

	private void Start()
	{
		Time.timeScale = 1f;
	}
}

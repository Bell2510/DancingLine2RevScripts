using System;
using UnityEngine;

public class TurnOff : MonoBehaviour
{
	public GameObject Object;
	
	private void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")
		{
			this.Object.gameObject.SetActive(false);
		}
	}
}

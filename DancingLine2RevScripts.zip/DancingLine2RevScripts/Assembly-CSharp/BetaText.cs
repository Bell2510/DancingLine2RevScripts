﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace DancingLine2RevScripts
{
    public class BetaText : MonoBehaviour
    {
        public Text About;
		public GameObject More;
	
	    void Start()
	    {
			
	    }
		
		void Update()
		{
			DontDestroyOnLoad(More);
		}
    }
}

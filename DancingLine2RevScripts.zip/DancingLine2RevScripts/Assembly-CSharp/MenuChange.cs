using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MenuChange : MonoBehaviour
{
	public float Level;
	public GameObject Prologue;
	public GameObject Game;
	public GameObject Sand;
	public GameObject Abyss;
	public GameObject CathedralEpic;
	public GameObject StormDance;
	public GameObject RanchWest;
	public Button PrologueButtonRight;
	public Button GameButtonLeft;
	public Button GameButtonRight;
	public Button SandButtonLeft;
	public Button SandButtonRight;
	public Button AbyssButtonLeft;
	public Button AbyssButtonRight;
	public Button CathedralEpicButtonLeft;
	public Button CathedralEpicButtonRight;
	public Button StormDanceButtonLeft;
	public Button RanchWestButtonLeft;
	public Button RanchWestButtonRight;
	public Button NewLevel1;
	public Button NewLevel2;
	public Button NewLevel3;
	public Button NewLevel4;
	public Button NewLevel5;
	public Button NewLevel6;
	
	private void Start()
	{
		Button component = this.PrologueButtonRight.GetComponent<Button>();
		Button component2 = this.GameButtonLeft.GetComponent<Button>();
		Button component3 = this.GameButtonRight.GetComponent<Button>();
		Button component4 = this.SandButtonLeft.GetComponent<Button>();
		Button component5 = this.SandButtonRight.GetComponent<Button>();
		Button component6 = this.AbyssButtonLeft.GetComponent<Button>();
		Button component7 = this.AbyssButtonRight.GetComponent<Button>();
		Button component8 = this.CathedralEpicButtonLeft.GetComponent<Button>();
		Button component9 = this.CathedralEpicButtonRight.GetComponent<Button>();
		Button component10 = this.StormDanceButtonLeft.GetComponent<Button>();
		Button component11 = this.RanchWestButtonRight.GetComponent<Button>();
		Button component12 = this.RanchWestButtonLeft.GetComponent<Button>();
		Button component13 = this.NewLevel1.GetComponent<Button>();
		Button component14 = this.NewLevel2.GetComponent<Button>();
		Button component15 = this.NewLevel3.GetComponent<Button>();
		Button component16 = this.NewLevel4.GetComponent<Button>();
		Button component17 = this.NewLevel5.GetComponent<Button>();
		Button component18 = this.NewLevel6.GetComponent<Button>();
		component.onClick.AddListener(new UnityAction(this.PrologueR));
		component2.onClick.AddListener(new UnityAction(this.GameL));
		component3.onClick.AddListener(new UnityAction(this.GameR));
		component4.onClick.AddListener(new UnityAction(this.SandL));
		component5.onClick.AddListener(new UnityAction(this.SandR));
		component6.onClick.AddListener(new UnityAction(this.AbyssL));
		component7.onClick.AddListener(new UnityAction(this.AbyssR));
		component8.onClick.AddListener(new UnityAction(this.CathedralEpicL));
		component9.onClick.AddListener(new UnityAction(this.CathedralEpicR));
		component10.onClick.AddListener(new UnityAction(this.StormDanceL));
		component11.onClick.AddListener(new UnityAction(this.RanchWestR));
		component12.onClick.AddListener(new UnityAction(this.RanchWestL));
		component13.onClick.AddListener(new UnityAction(this.NewLevel));
		component14.onClick.AddListener(new UnityAction(this.NewLevel));
		component15.onClick.AddListener(new UnityAction(this.NewLevel));
		component16.onClick.AddListener(new UnityAction(this.NewLevel));
		component17.onClick.AddListener(new UnityAction(this.NewLevel));
		component18.onClick.AddListener(new UnityAction(this.NewLevel));
	}

	private void PrologueR()
	{
		this.Level = 1f;
	}

	private void GameL()
	{
		this.Level = 0f;
	}

	private void GameR()
	{
		this.Level = 2f;
	}

	private void SandL()
	{
		this.Level = 1f;
	}

	private void SandR()
	{
		this.Level = 6f;
	}

	private void AbyssL()
	{
		this.Level = 6f;
	}

	private void AbyssR()
	{
		this.Level = 4f;
	}

	private void CathedralEpicL()
	{
		this.Level = 3f;
	}

	private void CathedralEpicR()
	{
		this.Level = 5f;
	}

	private void StormDanceL()
	{
		this.Level = 4f;
	}

	private void RanchWestR()
	{
		this.Level = 3f;
	}

	private void RanchWestL()
	{
		this.Level = 2f;
	}

	private void NewLevel()
	{
		this.Level = 6f;
	}

	private void Update()
	{
		if (this.Level == 0f)
		{
			this.Prologue.gameObject.SetActive(true);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 1f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(true);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 2f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(true);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 3f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(true);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 4f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(true);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 5f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(true);
			this.RanchWest.gameObject.SetActive(false);
		}
		if (this.Level == 6f)
		{
			this.Prologue.gameObject.SetActive(false);
			this.Game.gameObject.SetActive(false);
			this.Sand.gameObject.SetActive(false);
			this.Abyss.gameObject.SetActive(false);
			this.CathedralEpic.gameObject.SetActive(false);
			this.StormDance.gameObject.SetActive(false);
			this.RanchWest.gameObject.SetActive(true);
		}
	}
}

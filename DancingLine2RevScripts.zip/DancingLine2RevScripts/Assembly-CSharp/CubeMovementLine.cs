using System;
using UnityEngine;

public class CubeMovementLine : MonoBehaviour
{
	public GameObject Actor;
	public float speed = 1f;
	private Vector3 pos;
	public Material mat;
	private int loopCount = 1;
	public bool onGround = true;
	public float distFromGround = 0.6f;
	public bool isAlive = true;
	
	private void Start()
	{
	}

	private void Update()
	{
		if (this.isAlive)
		{
			this.onGround = this.isGrounded();
			this.pos = this.Actor.transform.position;
			this.Actor.transform.Translate(Vector3.forward * this.speed * Time.deltaTime);
			if (this.onGround)
			{
				GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject.transform.position = this.pos;
				gameObject.GetComponent<MeshRenderer>().material = this.mat;
				gameObject.GetComponent<BoxCollider>().isTrigger = true;
				if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
				{
					if (this.loopCount % 2 != 0)
					{
						this.Actor.transform.eulerAngles = new Vector3(0f, 90f, 0f);
						this.loopCount++;
					}
					else
					{
						this.Actor.transform.eulerAngles = new Vector3(0f, 0f, 0f);
						this.loopCount++;
					}
				}
			}
		}
	}

	public bool isGrounded()
	{
		return Physics.Raycast(this.Actor.transform.position, Vector3.down, this.distFromGround);
	}

	private void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.tag == "obstacle")
		{
			this.isAlive = false;
		}
	}
}

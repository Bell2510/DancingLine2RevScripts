using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
	public AudioClip[] audioClips;
	public Dictionary<string, AudioClip> clips;
	public static AudioManager instance;
	private AudioSource musicSource;
	
	private void Start()
	{
		this.musicSource = base.gameObject.AddComponent<AudioSource>();
		if (AudioManager.instance == null)
		{
			AudioManager.instance = this;
		}
		this.clips = new Dictionary<string, AudioClip>();
		for (int i = 0; i < this.audioClips.Length; i++)
		{
			this.clips.Add(this.audioClips[i].name, this.audioClips[i]);
		}
	}
	
	public void PlayMusic(string name)
	{
		this.PlayMusic(this.clips[name], 0f);
	}
	
	public void PlayMusic(string name, float time)
	{
		this.PlayMusic(this.clips[name], time);
	}
	
	public void PlayMusic(AudioClip clip, float startTime)
	{
		this.musicSource.Stop();
		this.musicSource.clip = clip;
		this.musicSource.time = startTime;
		this.musicSource.Play();
	}
	
	public void PlayOnce(string clipName, float delay, float volume)
	{
		this.PlayOnce(this.clips[clipName], delay, volume);
	}
	
	public void PlayOnce(AudioClip clip, float delay, float volume)
	{
		base.StartCoroutine(this.PlayOnceCoroutine(clip, delay, volume));
	}
	
	public void PlayOnce(string name)
	{
		AudioClip clip = this.clips[name];
		this.PlayOnce(clip, 0f, 1f);
	}
	
	private IEnumerator PlayOnceCoroutine(AudioClip clip, float delay, float volume)
	{
		yield return new WaitForSeconds(delay);
		AudioSource source = base.gameObject.AddComponent<AudioSource>();
		source.PlayOneShot(clip, volume);
		yield return new WaitForSeconds(clip.length);
		UnityEngine.Object.Destroy(source);
		yield break;
	}
	
	private void Update()
	{
	}
}

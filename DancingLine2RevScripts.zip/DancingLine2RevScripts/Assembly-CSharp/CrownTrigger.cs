﻿using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
//CodeByHTG

namespace DancingLine2RevScripts
{
    public class CrownTrigger : MonoBehaviour 
	{
		private string CodeByHTG;
        public GameObject Crown;
        public SpriteRenderer CrownBackgroundSprite;
        public SpriteRenderer CrownForegroundSprite;
        public ParticleSystem CrownParticles;

        public float Duration = 1.25f;

        private List<Tween> ParticleTweens;
        private MeshRenderer CrownRenderer;
        private Tween CrownBackgroundTween;
        private Tween CrownForegroundTween;
		
		private void Update()
		{
			Crown.transform.Rotate(Vector3.up, Time.deltaTime * 40f);
		}

        private void Start() 
		{
            CrownRenderer = Crown.GetComponent<MeshRenderer>();
            ParticleTweens = new List<Tween>();
        }
		
        public void Trigger() 
		{
            CrownParticles.transform.position = Crown.transform.position;
            CrownParticles.Clear();
            CrownParticles.Play();
            
            ParticleTweens.Add(CrownParticles.transform.DOMoveX(CrownForegroundSprite.transform.position.x, Duration));
            ParticleTweens[0].SetEase(Ease.InOutSine);

            ParticleTweens.Add(CrownParticles.transform.DOMoveZ(CrownForegroundSprite.transform.position.z, Duration));
            ParticleTweens[1].SetEase(Ease.InOutSine);
            
            ParticleTweens.Add(CrownParticles.transform.DOMoveY(CrownForegroundSprite.transform.position.y + 5f, Duration / 2f));
            ParticleTweens[2].SetEase(Ease.InSine);

            Tweener tweener = CrownParticles.transform.DOMoveY(CrownForegroundSprite.transform.position.y, Duration / 2f);
            tweener.SetEase(Ease.OutSine);
            tweener.SetDelay(Duration / 2f);
            tweener.OnStart(ShowCrownSprite);
            ParticleTweens.Add(tweener);
            ParticleTweens[3].OnComplete(ClearAllTweens);

            CrownRenderer.enabled = false;
        }

        private void ShowCrownSprite() 
		{
            CrownBackgroundTween = CrownBackgroundSprite.DOFade(1f, Duration / 4f);
            CrownBackgroundTween.SetEase(Ease.OutSine);
            CrownBackgroundTween.OnComplete(delegate 
			{
                CrownBackgroundTween.Kill();
            });
            
            
            CrownForegroundTween = CrownForegroundSprite.DOFade(1f, Duration / 4f);
            CrownForegroundTween.SetEase(Ease.OutSine);
            CrownForegroundTween.OnComplete(delegate 
			{
                CrownForegroundTween.Kill();
            });
        }

        private void ClearAllTweens() 
		{
            foreach (Tween tween in ParticleTweens)
            {
                tween.Kill();
            }
            
            ParticleTweens.Clear();
        }
    }
}
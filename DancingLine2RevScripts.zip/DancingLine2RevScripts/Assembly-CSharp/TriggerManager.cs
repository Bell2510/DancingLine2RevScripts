using System;
using System.Collections.Generic;
using UnityEngine;

public class TriggerManager
{
	private static Dictionary<int, List<Trigger>> groups = new Dictionary<int, List<Trigger>>();
	
	public static void Init()
	{
		TriggerManager.groups.Clear();
	}

	public static void AddObjectToGroup(int groupId, Trigger obj)
	{
		if (TriggerManager.groups.ContainsKey(groupId))
		{
			List<Trigger> list = TriggerManager.groups[groupId];
			list.Add(obj);
		}
		else
		{
			List<Trigger> list2 = new List<Trigger>();
			TriggerManager.groups.Add(groupId, list2);
			list2.Add(obj);
		}
	}

	public static void Call(GameObject obj)
	{
		if (obj == null)
		{
			return;
		}
		foreach (Trigger trigger in obj.GetComponents<Trigger>())
		{
			if (trigger.groupId == -1)
			{
				trigger.OnTriggerStart();
			}
		}
	}

	public static void Call(Trigger obj)
	{
		if (obj == null)
		{
			return;
		}
		foreach (Trigger trigger in obj.GetComponents<Trigger>())
		{
			if (obj.groupId == trigger.groupId)
			{
				trigger.OnTriggerStart();
			}
		}
	}

	public static void Call(int groupId)
	{
		List<Trigger> list = TriggerManager.groups[groupId];
		Debug.Log("Called groupId: " + groupId);
		foreach (Trigger obj in list)
		{
			TriggerManager.Call(obj);
		}
	}

	// Note: this type is marked as 'beforefieldinit'.
	static TriggerManager()
	{
	}
}

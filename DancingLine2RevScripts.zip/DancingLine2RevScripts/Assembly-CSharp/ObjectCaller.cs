using System;
using UnityEngine;

public class ObjectCaller : Trigger
{
	public GameObject obj;
	
	private void OnTriggerEnter()
	{
		this.CallTriggers();
	}

	private void CallTriggers()
	{
		TriggerManager.Call(this.obj);
	}
}

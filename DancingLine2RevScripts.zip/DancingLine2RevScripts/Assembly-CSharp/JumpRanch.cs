using System;
using UnityEngine;

public class JumpRanch : MonoBehaviour
{
	public float thrust = 5f;
	
	private void Start()
	{
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
		{
			GameObject[] array = GameObject.FindGameObjectsWithTag("CubeJump");
			foreach (GameObject gameObject in array)
			{
				gameObject.GetComponent<Rigidbody>().AddForce(base.transform.up * this.thrust);
			}
		}
	}
}

using System;
using UnityEngine;
using UnityEngine.UI;

public class GemCollected : MonoBehaviour
{
	public Text gemcount;
	public Text gemcount2;
	public int count;
	
	private void Start()
	{
		this.count = 0;
		this.SetCountText();
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Gem")
		{
			this.count++;
			this.SetCountText();
		}
	}

	private void SetCountText()
	{
		this.gemcount.text = this.count.ToString() + "/10";
		this.gemcount2.text = this.count.ToString();
	}
}

using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
	public int approxSecondsToFade;
	public float defaultSpeed = 20f;
	public static PlayerController instance;
	public GameObject linePrefab;
	public UIFader Result;
	public UIFader Result2;
	private Rigidbody rb;
	private GameObject trail;
	private MeshRenderer meshRenderer;
	public Text percentage;
	public Text percentage2;
	public AudioClip MusicClip;
	public AudioSource MusicSource;
	public int CurrentPercentage;
	public GameObject UI;
	public GameObject UIComplete;
	public Button ButtonToStartGame;
	public Button ButtonToDeleteCube1;
	public GameObject UIStart;
	public GameObject Rotator;
	public bool StartForward = true;
	private bool state;
	private bool isPaused = true;
	private bool lastGrounded;
	public bool isAlive;
	public bool started;
	public float speed = 2f;
	public float startMusicTime;
	private Vector3 direction;
	private float startTime;
	private int lastPercent;
	public bool flipForward;
	public bool flipLeft;
	public int CrownCollected = 0;
	
	private void Start()
	{
		Button component = this.ButtonToStartGame.GetComponent<Button>();
		Button component2 = this.ButtonToDeleteCube1.GetComponent<Button>();
		this.SetPercentageText();
		this.MusicSource.clip = this.MusicClip;
		PlayerController.instance = this;
		this.rb = base.GetComponent<Rigidbody>();
		this.isAlive = false;
		component.onClick.AddListener(new UnityAction(this.TaskOnClick));
		component2.onClick.AddListener(new UnityAction(this.DeleteCube1));
		this.state = this.StartForward;
		Application.targetFrameRate = 60;
		this.ChangeTrails();
		this.MusicSource.Stop();
	}

	public bool CheckGrounded()
	{
		return Physics.Raycast(base.transform.position, Vector3.down, 1.2f);
	}

	public void SetFlipDirection(bool forward, bool left)
	{
		this.flipForward = forward;
		this.flipLeft = left;
	}

	private void TaskOnClick()
	{
		this.isAlive = true;
		this.UIStart.gameObject.SetActive(false);
		GameObject[] array = GameObject.FindGameObjectsWithTag("Cube1");
		foreach (GameObject obj in array)
		{
			UnityEngine.Object.Destroy(obj);
		}
	}

	private void DeleteCube1()
	{
		GameObject[] array = GameObject.FindGameObjectsWithTag("Cube1");
		foreach (GameObject obj in array)
		{
			UnityEngine.Object.Destroy(obj);
		}
	}

	private void Update()
	{
		if (this.isAlive)
		{
			bool flag = this.CheckGrounded();
			bool flag2 = Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0);
			if (Input.touchCount > 0)
			{
				flag2 |= (Input.GetTouch(0).phase == TouchPhase.Began);
			}
			if (Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
			{
				this.ReloadCurrentMap();
			}
			float num = this.startMusicTime + Time.time - this.startTime;
			float f = num / 112f * 100f;
			if (flag2 && this.isPaused)
			{
				this.isPaused = false;
				this.startTime = Time.time;
				this.MusicSource.Play();
			}
			if (flag2 && flag)
			{
				this.SetPercentageText();
				this.ChangeTrails();
				Debug.Log(Time.time - this.startTime);
				this.state = !this.state;
				if (this.state)
				{
					this.direction = ((!this.flipForward) ? Vector3.forward : Vector3.back);
				}
				else
				{
					this.direction = ((!this.flipLeft) ? Vector3.left : Vector3.right);
				}
			}
			int num2 = Mathf.FloorToInt(f);
			this.lastPercent = num2;
			if (num2 % 10 == 0)
			{
			}
			if (this.isPaused)
			{
				return;
			}
			Vector3 vector = this.direction;
			vector *= this.speed * Time.deltaTime;
			base.transform.Translate(vector);
			if (flag)
			{
				this.trail.transform.localScale += vector;
				this.trail.transform.position += vector / 2f;
				if (flag != this.lastGrounded)
				{
					this.ChangeTrails();
				}
			}
			this.lastGrounded = flag;
		}
		else
		{
			this.MusicSource.volume = this.MusicSource.volume - Time.deltaTime / (float)this.approxSecondsToFade;
		}
	}

	private void ChangeTrails()
	{
		this.trail = UnityEngine.Object.Instantiate<GameObject>(this.linePrefab);
		this.trail.transform.position = base.transform.position;
		Vector3 localScale = this.trail.transform.localScale;
		int num = 1;
		int num2 = 1;
		if (this.flipForward)
		{
			if (this.state)
			{
				num = -1;
			}
			else
			{
				num2 = -1;
			}
		}
		if (this.flipLeft)
		{
			if (this.state)
			{
				num2 = -1;
				num = 1;
			}
			else
			{
				num = -1;
				num2 = 1;
			}
		}
		this.trail.transform.localScale = new Vector3(localScale.x * (float)num, localScale.y, localScale.z * (float)num2);
	}

	public void ReloadCurrentMap()
	{
		Scene activeScene = SceneManager.GetActiveScene();
		TriggerManager.Init();
		SceneManager.LoadScene(activeScene.buildIndex);
	}

	private void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.tag == "obstacle")
		{
			this.isAlive = false;
			this.UI.gameObject.SetActive(true);
			this.Result.FadeIn();
			this.Rotator.gameObject.SetActive(false);
		}
		if (collision.gameObject.tag == "endobstacle")
		{
			this.isAlive = false;
			this.UIComplete.gameObject.SetActive(true);
			this.Result2.FadeIn();
			this.Rotator.gameObject.SetActive(false);
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.tag == "Gem")
		{
			other.gameObject.SetActive(false);
		}
		if (other.gameObject.tag == "Crown")
		{
			other.gameObject.SetActive(false);
			this.CrownCollected += 1;
		}
	}

	private void SetPercentageText()
	{
		if (this.CurrentPercentage < 100 && this.isAlive)
		{
			this.CurrentPercentage = Mathf.RoundToInt(this.MusicSource.time / (this.MusicClip.length - 6f) * 100f);
			this.percentage.text = this.CurrentPercentage.ToString() + "%";
			this.percentage2.text = this.CurrentPercentage.ToString();
		}
	}
}

﻿using UnityEngine.UI;
using UnityEngine;
using System;
using DG.Tweening;

namespace DancingLine2RevScripts
{
	public class OverPage : MonoBehaviour
	{
		[HideInInspector] public GameObject OverPageObject;
		public CubeMovementLineCathedral Line;
		public GemCollected LineGem;
		[Serializable]
		public class CrownGroup
		{
			public Image Crown1;
			public Image Crown2;
			public Image Crown3;
		}
		
		[Serializable]
		public class Progress
		{
			public Image FillBar;
			public Image PerfectImage;
			public Text LevelName;
			public Text LevelDia;
			public Text LevelPer;
			public int CrownCount;
			public int DiaCount;
			public int PerCount;
			public string TheName;
			[HideInInspector] public bool IsPerfect;
		}
		
		public CrownGroup CrownGroupObject;
		public Progress ProgressInformation;
		void Start()
		{
			ProgressInformation.LevelName.text = ProgressInformation.TheName.ToString();
		}
		
		void Update()
		{
			ProgressInformation.IsPerfect = false;
			ProgressInformation.PerfectImage.gameObject.SetActive(false);
			ProgressInformation.FillBar.fillAmount = ProgressInformation.PerCount / 100f;
			ProgressInformation.DiaCount = this.LineGem.count;
			ProgressInformation.PerCount = this.Line.CurrentPercentage;
			ProgressInformation.CrownCount = this.Line.CrownCollected;
			
			if (ProgressInformation.CrownCount == 3)
			{
				CrownGroupObject.Crown1.enabled = true;
				CrownGroupObject.Crown2.enabled = true;
				CrownGroupObject.Crown3.enabled = true;
				ProgressInformation.PerfectImage.gameObject.SetActive(true);
			}
			if (ProgressInformation.CrownCount == 2)
			{
				CrownGroupObject.Crown1.enabled = true;
				CrownGroupObject.Crown2.enabled = true;
				CrownGroupObject.Crown3.enabled = false;
				ProgressInformation.PerfectImage.gameObject.SetActive(false);
			}
			if (ProgressInformation.CrownCount == 1)
			{
				CrownGroupObject.Crown1.enabled = true;
				CrownGroupObject.Crown2.enabled = false;
				CrownGroupObject.Crown3.enabled = false;
				ProgressInformation.PerfectImage.gameObject.SetActive(false);
			}
			if (ProgressInformation.CrownCount == 0)
			{
				CrownGroupObject.Crown1.enabled = false;
				CrownGroupObject.Crown2.enabled = false;
				CrownGroupObject.Crown3.enabled = false;
				ProgressInformation.PerfectImage.gameObject.SetActive(false);
			}
			
			if (ProgressInformation.CrownCount == 3 && ProgressInformation.DiaCount == 10 && ProgressInformation.PerCount == 100)
			{
				ProgressInformation.PerfectImage.gameObject.SetActive(true);
			}
			else if (ProgressInformation.CrownCount <= 3 && ProgressInformation.DiaCount <= 10 && ProgressInformation.PerCount <= 100)
			{
				ProgressInformation.PerfectImage.gameObject.SetActive(false);
			}
		}
	}
}

using System;
using UnityEngine;
using UnityEngine.UI;

public class PrologueMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestPrologue", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestPrologue", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

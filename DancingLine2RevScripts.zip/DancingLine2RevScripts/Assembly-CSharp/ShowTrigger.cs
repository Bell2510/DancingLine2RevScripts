using System;

public class ShowTrigger : Trigger
{
	public bool beforeHide;
	
	public override void Start()
	{
		base.Start();
		base.gameObject.SetActive(!this.beforeHide);
	}

	private void OnTriggerEnter()
	{
		base.gameObject.SetActive(true);
	}
}

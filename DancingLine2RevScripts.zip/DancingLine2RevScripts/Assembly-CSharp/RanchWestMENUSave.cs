using System;
using UnityEngine;
using UnityEngine.UI;

public class RanchWestMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestRanchWest", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestRanchWest", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

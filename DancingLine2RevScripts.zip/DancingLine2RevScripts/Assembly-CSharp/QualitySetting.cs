﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class QualitySetting : MonoBehaviour
{
	public Text shower;
	[HideInInspector] public string qua = "Quality：";
	[HideInInspector] public string vl = "Very Low";
	[HideInInspector] public string l = "Low";
	[HideInInspector] public string m = "Medium";
	[HideInInspector] public string h = "High";
	[HideInInspector] public string vh = "Very High";
	[HideInInspector] public string u = "Ultra";
	[HideInInspector] public int id;
	
	private void Start()
	{
		this.id = QualitySettings.GetQualityLevel() + 1;
	}

	public void click()
	{
		this.id++;
	}

	private void Update()
	{
		if (this.id <= 1)
		{
			QualitySettings.SetQualityLevel(0);
			this.shower.text = this.qua + this.vl;
		}
		if (this.id == 2)
		{
			QualitySettings.SetQualityLevel(1);
			this.shower.text = this.qua + this.l;
		}
		if (this.id == 3)
		{
			QualitySettings.SetQualityLevel(2);
			this.shower.text = this.qua + this.m;
		}
		if (this.id == 4)
		{
			QualitySettings.SetQualityLevel(3);
			this.shower.text = this.qua + this.h;
		}
		if (this.id == 5)
		{
			QualitySettings.SetQualityLevel(4);
			this.shower.text = this.qua + this.vh;
		}
		if (this.id == 6)
		{
			QualitySettings.SetQualityLevel(5);
			this.shower.text = this.qua + this.u;
		}
		if (this.id > 6)
		{
			this.id = 1;
		}
		if (this.id < 1)
		{
			this.id = 1;
		}
	}
}

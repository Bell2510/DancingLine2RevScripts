using System;
using UnityEngine;

public class TurnOn : MonoBehaviour
{
	public GameObject Object;
	
	private void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")
		{
			this.Object.gameObject.SetActive(true);
		}
	}
}

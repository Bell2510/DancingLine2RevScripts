using System;
using System.Collections;
using UnityEngine;

public class UIFader : MonoBehaviour
{
	public CanvasGroup uiElement;
	
	public void FadeIn()
	{
		base.StartCoroutine(this.FadeCanvasGroup(this.uiElement, this.uiElement.alpha, 1f, 0.5f));
	}

	public void FadeOut()
	{
		base.StartCoroutine(this.FadeCanvasGroup(this.uiElement, this.uiElement.alpha, 0f, 0.5f));
	}

	public IEnumerator FadeCanvasGroup(CanvasGroup cg, float start, float end, float lerpTime = 1f)
	{
		float _timeStartedLerping = Time.time;
		float timeSinceStarted = Time.time - _timeStartedLerping;
		float percentageComplete = timeSinceStarted / lerpTime;
		for (;;)
		{
			timeSinceStarted = Time.time - _timeStartedLerping;
			percentageComplete = timeSinceStarted / lerpTime;
			float currentValue = Mathf.Lerp(start, end, percentageComplete);
			cg.alpha = currentValue;
			if (percentageComplete >= 1f)
			{
				break;
			}
			yield return new WaitForFixedUpdate();
		}
		MonoBehaviour.print("done");
		yield break;
	}
}

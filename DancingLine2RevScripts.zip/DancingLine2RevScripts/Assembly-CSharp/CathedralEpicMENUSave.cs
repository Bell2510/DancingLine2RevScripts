using UnityEngine;
using UnityEngine.UI;

public class CathedralEpicMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestCathedralEpic", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestCathedralEpic", 0);
		this.HighScoreGems.text = int2.ToString();
	}
}

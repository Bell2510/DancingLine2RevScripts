﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class ResolutionShower : MonoBehaviour
{
	public Text ResolutionShowText;
	public GameObject FullScreenShower;
	
	private void Start()
	{
		
	}

	private void Update()
	{
		if (this.ResolutionShowText != null)
		{
			this.ResolutionShowText.text = Screen.width.ToString() + "x" + Screen.height.ToString();
		}
		if (this.FullScreenShower != null)
		{
			this.FullScreenShower.SetActive(Screen.fullScreen);
		}
	}

	public void SetFullScreen()
	{
		if (Screen.fullScreen)
		{
			Screen.fullScreen = false;
			return;
		}
		Screen.fullScreen = true;
	}
}

﻿using UnityEngine.UI;
using UnityEngine;
using System;
using DG.Tweening;

namespace DancingLine2RevScripts
{
    public class StartUI : MonoBehaviour
	{
		[Header ("Settings")]
		public SkinManager SkinPannel;
		public Animator HandObject;
		
		[Header ("Animator Doer1")]
		public GameObject CanvasLoading;
		public float TimeDoer1;
		public Ease EaseFade;
		
		[Header ("Animator Doer2")]
		public GameObject BackButton;
		public float TimeDoer2;
		public Vector2 BackPos;
		public Ease EasePos;
	}
}

using System;
using UnityEngine;

public class SoundTrigger : Trigger
{
	public AudioClip audioClip;
	public float volume = 1f;
	
	public override void Start()
	{
		base.Start();
	}

	private void OnTriggerEnter()
	{
		AudioManager instance = AudioManager.instance;
		instance.PlayOnce(this.audioClip, 0f, this.volume);
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace DancingLine2RevScripts{
	public class PostInt : MonoBehaviour{
		public void SetPostNumber(int NumberInt) {
			PlayerPrefs.SetInt("PostData", NumberInt);
			if (NumberInt < 1) {
				PlayerPrefs.SetInt("PostData", 1);
			}
			if (NumberInt > 1) {
				PlayerPrefs.SetInt("PostData", 2);
			}
			if (NumberInt < 2) {
				PlayerPrefs.SetInt("PostData", 2);
			}
			if (NumberInt > 2) {
				PlayerPrefs.SetInt("PostData", 1);
			}
		}
		
		public void SwitchPost(int Value, Text Shower, string Show1, string Show2) {
			PlayerPrefs.SetInt("PostData", Value);
			if (Value < 1) {
				PlayerPrefs.SetInt("PostData", 1);
				Shower.text = Show1;
			}
			if (Value > 1) {
				PlayerPrefs.SetInt("PostData", 2);
				Shower.text = Show2;
			}
			if (Value < 2) {
				PlayerPrefs.SetInt("PostData", 2);
				Shower.text = Show2;
			}
			if (Value > 2) {
				PlayerPrefs.SetInt("PostData", 1);
				Shower.text = Show1;
			}
		}
	}
}

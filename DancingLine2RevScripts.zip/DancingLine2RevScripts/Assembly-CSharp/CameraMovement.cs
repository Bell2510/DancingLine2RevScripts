using System;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
	public GameObject Player;
	[Range(0.0001f, 1f)]
	public float SmoothFactor = 0.5f;
	public bool LookAtPlayer;
	private Vector3 _cameraOffset;
	
	private void Start()
	{
		this._cameraOffset = base.transform.position - this.Player.transform.position;
	}
	
	private void Update()
	{
		Vector3 b = this.Player.transform.position + this._cameraOffset;
		base.transform.position = Vector3.Slerp(base.transform.position, b, this.SmoothFactor);
		if (this.LookAtPlayer)
		{
			base.transform.LookAt(this.Player.transform);
		}
	}
}

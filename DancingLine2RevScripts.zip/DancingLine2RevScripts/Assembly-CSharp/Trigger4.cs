using System;
using UnityEngine;

public class Trigger4 : MonoBehaviour
{
	public Animator anim;
	
	private void Start()
	{
		this.anim.enabled = false;
	}

	private void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")
		{
			this.anim.enabled = true;
		}
	}
}

using System;
using UnityEngine;

public class MusicTrigger : Trigger
{
	public AudioClip audioClip;
	
	public override void Start()
	{
		base.Start();
	}

	private void OnTriggerEnter()
	{
		AudioManager instance = AudioManager.instance;
		instance.PlayMusic(this.audioClip, 0f);
	}
}

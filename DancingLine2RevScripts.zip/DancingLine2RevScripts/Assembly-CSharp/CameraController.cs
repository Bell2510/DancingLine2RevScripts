using System;
using UnityEngine;

public class CameraController : MonoBehaviour
{
	public Vector3 targetDistance;
	private Vector3 startPos;
	private Vector3 distance;
	public GameObject playerObj;
	public static CameraController instance;
	public PlayerController playerController;
	
	private void Start()
	{
		this.startPos = base.transform.position;
		this.playerObj = GameObject.FindWithTag("Player");
		this.playerController = GameObject.FindWithTag("Player").GetComponent<PlayerController>();
		CameraController.instance = this;
	}
	
	private void Update()
	{
		this.startPos = base.transform.position;
		this.playerObj = GameObject.FindWithTag("Player");
		this.playerController = GameObject.FindWithTag("Player").GetComponent<PlayerController>();
		CameraController.instance = this;
		this.distance = Vector3.Slerp(this.distance, this.targetDistance, Time.deltaTime);
		float num = this.playerController.speed / this.playerController.defaultSpeed;
		Vector3 b = this.playerObj.transform.position + this.distance;
		base.transform.position = Vector3.Slerp(base.transform.position, b, Time.deltaTime * num);
		Quaternion b2 = Quaternion.LookRotation(this.playerObj.transform.position - base.transform.position);
		base.transform.rotation = Quaternion.Slerp(base.transform.rotation, b2, Time.deltaTime);
	}
}

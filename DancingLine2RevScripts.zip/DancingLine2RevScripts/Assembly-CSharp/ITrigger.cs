using System;

public interface ITrigger
{
	void OnTrigger();
	void OnTriggerStart();
	void OnTriggerEnd();
	void Dispose();
}

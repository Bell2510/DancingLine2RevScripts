using System;
using UnityEngine;
using UnityEngine.UI;

public class AbyssMENUSave : MonoBehaviour
{
	public Text HighScore;
	public Text HighScoreGems;
	
	private void Start()
	{
		int @int = PlayerPrefs.GetInt("BestAbyss", 0);
		this.HighScore.text = @int.ToString();
		int int2 = PlayerPrefs.GetInt("GemsBestAbyss", 0);
		this.HighScoreGems.text = int2.ToString();
		if (@int > 95)
		{
			this.HighScore.text = "100";
		}
	}
}

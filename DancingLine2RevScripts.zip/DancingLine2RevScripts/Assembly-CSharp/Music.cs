using System;
using UnityEngine;

public class Music : MonoBehaviour
{
	public bool MusicPlay;
	public AudioClip Clip;
	
	private void Update()
	{
		if (this.MusicPlay)
		{
			
		}
	}
}

using System;
using UnityEngine;

public class movement : MonoBehaviour
{
	private void Update()
	{
		base.transform.position = new Vector3(base.transform.position.x, base.transform.position.y + 0.02f, base.transform.position.z);
	}
}

using System;
using UnityEngine;

public class CameraDistanceTrigger : Trigger
{
	public Vector3 targetDistance;
	
	private void OnTriggerEnter()
	{
		CameraController.instance.targetDistance = this.targetDistance;
	}
}

using System;
using UnityEngine;
using System.Collections.Generic;

public class CollisionListener : MonoBehaviour
{
	public List<GameObject> objects;
	public List<int> groups;
	public bool isCallSelf;
	
	private void Start()
	{
	}
	
	private void Update()
	{
	}
	
	private void OnTriggerEnter(Collider collider)
	{
		Debug.Log("ㅇㅇ");
		if (collider.CompareTag("Player"))
		{
			this.CallTriggers();
		}
	}

	private void OnCollisionEnter(Collision collision)
	{
		Debug.Log("ㅇㅇ");
		Collider collider = collision.collider;
		if (collider.CompareTag("Player"))
		{
			this.CallTriggers();
		}
	}

	private void CallTriggers()
	{
		if (this.isCallSelf)
		{
			TriggerManager.Call(base.gameObject);
		}
		if (this.objects.Count > 0)
		{
			for (int i = 0; i < this.objects.Count; i++)
			{
				TriggerManager.Call(this.objects[i]);
			}
		}
		if (this.groups.Count > 0)
		{
			for (int j = 0; j < this.groups.Count; j++)
			{
				TriggerManager.Call(this.groups[j]);
			}
		}
	}
}

using System;
using UnityEngine;

public class Move : MonoBehaviour
{
	public GameObject linePrefab;
	private GameObject trail;
	private bool state;
	private bool isPaused = true;
	private bool lastGrounded;
	public float speed = 20f;
	private Vector3 direction;
	
	private void Start()
	{
		this.ChangeTrails();
	}

	public bool CheckGrounded()
	{
		return Physics.Raycast(base.transform.position, Vector3.down, 1.1f);
	}

	private void Update()
	{
		bool flag = this.CheckGrounded();
		bool flag2 = Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0);
		if (flag2 && this.isPaused)
		{
			this.isPaused = false;
		}
		if (flag2 && flag)
		{
			this.state = !this.state;
			this.ChangeTrails();
		}
		if (this.isPaused)
		{
			return;
		}
		Vector3 vector = default(Vector3);
		if (this.state)
		{
			this.direction = Vector3.forward;
		}
		else
		{
			this.direction = Vector3.left;
		}
		vector = this.direction;
		vector *= this.speed * Time.deltaTime;
		base.transform.Translate(vector);
		if (flag)
		{
			this.trail.transform.localScale += vector;
			this.trail.transform.position += vector / 2f;
			if (flag != this.lastGrounded)
			{
				this.ChangeTrails();
			}
		}
		this.lastGrounded = flag;
	}
	
	private void ChangeTrails()
	{
		this.trail = UnityEngine.Object.Instantiate<GameObject>(this.linePrefab);
		this.trail.transform.position = base.transform.position;
	}
}

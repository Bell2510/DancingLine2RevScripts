using UnityEngine;

public class TriggerAni : MonoBehaviour
{
	public Animator anim;

	private void Start()
	{
		anim.enabled = false;
	}


	private void OnTriggerEnter(Collider col)
	{
		if (col.gameObject.tag == "Player")
		{
			anim.enabled = true;
		}
	}
}

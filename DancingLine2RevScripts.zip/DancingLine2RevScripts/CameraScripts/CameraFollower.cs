﻿using System;
using DG.Tweening;
using UnityEngine;

public class CameraFollower : MonoBehaviour
{
	public CubeMovementLineCathedral Player;
	private Transform Camera;
	public Vector3 AddPosition = Vector3.zero;
	public Vector3 Rotate = new Vector3(45f, 45f, 0f);
	public float DistanceFromObject = 25f;
	public float FollowSpeed = 1.2f;
	public bool Following = true;
	public Tween DoPos;
	public Tween DoRot;
	public Tween DoDis;
	public Tween DoSpe;
	
	private void Start()
	{
		this.Camera = base.transform.GetChild(0);
	}

	private void Update()
	{
		if (this.Following)
		{
			base.transform.eulerAngles = this.Rotate;
			this.Camera.localPosition = new Vector3(0f, 0f, -this.DistanceFromObject);
			Vector3 b = this.Player.transform.position + this.AddPosition;
			base.transform.position = Vector3.Slerp(base.transform.position, b, Mathf.Abs(this.FollowSpeed * Time.deltaTime));
		}
		if (this.Player.isAlive && this.Following)
		{
			this.Following = false;
			this.DoPos.Kill(false);
			this.DoRot.Kill(false);
			this.DoDis.Kill(false);
			this.DoSpe.Kill(false);
		}
	}
}

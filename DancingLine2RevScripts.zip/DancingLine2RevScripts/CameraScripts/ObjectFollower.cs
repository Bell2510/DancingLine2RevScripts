﻿using System;
using UnityEngine;

namespace MaxIceFlameTemplate.Basic
{
	// Token: 0x020000D5 RID: 213
	public class ObjectFollower : MonoBehaviour
	{
		// Token: 0x06000383 RID: 899 RVA: 0x00018181 File Offset: 0x00016381
		private void Start()
		{
			base.transform.Rotate(this.Rotation);
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00018194 File Offset: 0x00016394
		private void Update()
		{
			base.transform.position = Vector3.SmoothDamp(base.transform.position, this.FollowObject.position + this.Position, ref this.Velocity, this.SmoothTime * (Time.deltaTime * 45f));
		}

		// Token: 0x04000476 RID: 1142
		public Transform FollowObject;

		// Token: 0x04000477 RID: 1143
		public float SmoothTime = 0.5f;

		// Token: 0x04000478 RID: 1144
		private Vector3 Velocity = Vector3.zero;

		// Token: 0x04000479 RID: 1145
		public Vector3 Position = Vector3.zero;

		// Token: 0x0400047A RID: 1146
		public Vector3 Rotation = Vector3.zero;
	}
}

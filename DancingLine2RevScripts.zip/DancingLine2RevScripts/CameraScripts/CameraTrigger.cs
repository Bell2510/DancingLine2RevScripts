﻿using System;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;

public class CameraTrigger : MonoBehaviour{
	public CameraFollower SetCamera;
	public bool ActivePosition = true;
	public Vector3 NewAddPosition = Vector3.zero;
	public bool ActiveRotate = true;
	public Vector3 NewRotate = new Vector3(45f, 45f, 0f);
	public bool ActiveDistance = true;
	public float NewDistance = 25f;
	public bool ActiveSpeed = true;
	public float NewFollowSpeed = 1.2f;
	public Ease Ease = Ease.InOutSine;
	public float NeedTime = 2f;

	private void OnTriggerEnter(Collider other){
		if (other.gameObject.tag == "Player" && other.gameObject.tag != null){
			if (this.SetCamera.DoPos != null){
				this.SetCamera.DoPos.Kill(false);
			}
			if (this.SetCamera.DoRot != null){
				this.SetCamera.DoRot.Kill(false);
			}
			if (this.SetCamera.DoDis != null){
				this.SetCamera.DoDis.Kill(false);
			}
			if (this.SetCamera.DoSpe != null){
				this.SetCamera.DoSpe.Kill(false);
			}
			if (this.ActivePosition){
				this.SetCamera.DoPos = DOTween.To(() => this.SetCamera.AddPosition, delegate(Vector3 a){
					this.SetCamera.AddPosition = a;
				}, this.NewAddPosition, this.NeedTime).SetEase(this.Ease);
			}
			if (this.ActiveRotate){
				this.SetCamera.DoRot = DOTween.To(() => this.SetCamera.Rotate, delegate(Vector3 a){
					this.SetCamera.Rotate = a;
				}, this.NewRotate, this.NeedTime).SetEase(this.Ease);
			}
			if (this.ActiveDistance){
				this.SetCamera.DoDis = DOTween.To(() => this.SetCamera.DistanceFromObject, delegate(float a){
					this.SetCamera.DistanceFromObject = a;
				}, this.NewDistance, this.NeedTime).SetEase(this.Ease);
			}
			if (this.ActiveSpeed){
				this.SetCamera.DoSpe = DOTween.To(() => this.SetCamera.FollowSpeed, delegate(float a){
					this.SetCamera.FollowSpeed = a;
				}, this.NewFollowSpeed, this.NeedTime).SetEase(this.Ease);
			}
		}
	}
}

﻿using UnityEngine;

public class CameraShakeTrigger : MonoBehaviour{
    public CameraShake CameraShake;
    public float seconds = 1f;
    public float quake = 2f;

    void OnTriggerEnter(Collider other){
        if (other.gameObject.tag == "Player"){
            CameraShake.ShakeFor(seconds, quake);
        }
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

namespace DancingLine2RevScripts
{
    public class GetMenu : MonoBehaviour
	{
		public string LevelStringDia;
		public string LevelStringPer;
		public Text LevelDia;
		public Text LevelPer;
		
		private void Update()
		{
			int _int1 = PlayerPrefs.GetInt(LevelStringDia, 0);
			LevelDia.text = _int1.ToString();
			int _int2 = PlayerPrefs.GetInt(LevelStringPer, 0);
			LevelPer.text = _int2.ToString();
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

namespace DancingLine2RevScripts
{
    public class Save : MonoBehaviour
	{
		[Header("Dia")]
		public Text SaveDiaText;
		public Text HighDia;
		
		[Header("Per")]
		public Text SavePerText;
		public Text HighPer;
		
		[Header("Cro")]
		public Text SaveCroText;
		public Text HighCro;
		
		[Header("Infos")]
		public string LevelDia;
		public string LevelPer;
		public string LevelCro;
		
		private void Start()
		{
			int _int = PlayerPrefs.GetInt(LevelDia, 0);
			this.HighDia.text = _int.ToString();
			int _intper = PlayerPrefs.GetInt(LevelPer, 0);
			this.HighPer.text = _intper.ToString();
		}
		
		private void Update()
		{
			int num1;
			int.TryParse(this.SavePerText.text, out num1);
			int _intper = PlayerPrefs.GetInt(LevelPer, 0);
			if (num1 > _intper)
			{
				this.HighPer.text = num1.ToString();
			    PlayerPrefs.SetInt(LevelPer, num1);
			}
			
			int num2;
			int.TryParse(this.SaveDiaText.text, out num2);
			int _int = PlayerPrefs.GetInt(LevelDia, 0);
			if (num2 > _int)
			{
				this.HighDia.text = num1.ToString();
				PlayerPrefs.SetInt(LevelDia, num2);
			}
		}
		
	}
}

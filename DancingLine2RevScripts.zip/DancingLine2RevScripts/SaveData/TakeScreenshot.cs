using System;
using UnityEngine;

public class TakeScreenshot : MonoBehaviour
{
	public int resolution = 3;
	public string imageName = "Screenshot_";
	public string path;
	public bool resetIndex;
	public string photopath;
	public bool ShowText;
	private int index;
	
	private void Awake()
	{
		if (this.resetIndex)
		{
			PlayerPrefs.SetInt("ScreenshotIndex", 0);
		}
		this.index = ((PlayerPrefs.GetInt("ScreenshotIndex") == 0) ? 1 : PlayerPrefs.GetInt("ScreenshotIndex"));
		this.path = Application.dataPath;
	}

	public void Screen()
	{
		ScreenCapture.CaptureScreenshot(string.Concat(new object[]
			{
				this.path,
				this.imageName,
				this.index,
				".png"
			}), this.resolution);
			this.index++;
			this.photopath = string.Concat(new object[]
			{
				"Screenshot saved: ",
				this.path,
				"-",
				this.imageName,
				this.index - 1
			});
			this.ShowText = true;
	}

	private void OnApplicationQuit()
	{
		PlayerPrefs.SetInt("ScreenshotIndex", this.index);
	}
}

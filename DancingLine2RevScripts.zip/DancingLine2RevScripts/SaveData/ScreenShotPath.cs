using System;
using UnityEngine;
using UnityEngine.UI;

public class ScreenShotPath : MonoBehaviour
{
	public Text screenshotpath;

	public TakeScreenshot screenshotscript;

	public CanvasGroup screenshot;

	private float maxTime = 6f;

	private float waitTime = 1f;

	private float CurrentTime;

	private float WaitTime;

	private void Start()
	{
		CurrentTime = 0f;
		WaitTime = 0f;
	}

	private void Update()
	{
		if (!screenshotscript.ShowText)
		{
			return;
		}
		screenshotpath.text = screenshotscript.photopath;
		screenshot.alpha = 0f;
		if (WaitTime < waitTime)
		{
			WaitTime += Time.deltaTime;
			return;
		}
		screenshot.alpha = 1f;
		if (CurrentTime < maxTime)
		{
			CurrentTime += Time.deltaTime;
			return;
		}
		screenshot.alpha = 0f;
		screenshotscript.ShowText = false;
		CurrentTime = 0f;
		WaitTime = 0f;
	}
}
